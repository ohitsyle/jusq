#!/bin/bash
# Post-deploy hook to ensure server starts correctly
# Elastic Beanstalk will automatically run npm start, but this ensures it works

cd /var/app/current
npm start
